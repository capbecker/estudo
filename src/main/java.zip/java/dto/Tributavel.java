package dto;

/**
 * Interface de contas que são tributaveis
 */
public interface Tributavel {

	double getValorImposto();
}
